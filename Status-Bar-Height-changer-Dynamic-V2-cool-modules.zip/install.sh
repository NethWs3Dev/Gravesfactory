SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE = "/system/product/overlay"

print_modname() {
ui_print "********************************" 
ui_print "  " 
ui_print "follow @cool_modules on telegram for more...."
ui_print "  " 
ui_print " Change statusbar height from Display Cutout" 
ui_print "  " 
ui_print "********************************"
}

on_install() {
   ui_print " Installing module please wait... "
   ui_print " Statusbar height changer(Dynamic) by : @Jai_08 "
   

unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
if [ -d /system/vendor/overlay ]; then
OPATH=$MODPATH/system/vendor/overlay
OPATH2=$MODPATH/system/product/overlay
mkdir -p $OPATH
mv $OPATH2/* $OPATH
rm -r $MODPATH/system/product
fi
  set_perm_recursive $MODPATH 0 0 0755 0644
}
